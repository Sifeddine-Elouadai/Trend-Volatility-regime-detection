# Market Regime Detection — Trend × Volatility

A rule-based, look-ahead-free framework that classifies daily market conditions into six structurally distinct regimes using price trend and realised volatility. Built on SPY (S&P 500 ETF) with full backtest statistics, a confidence score, and a suite of professional visualisations.

---

## What It Does

Instead of predicting where the market will go, this framework answers a more useful question: **what kind of environment is the market in right now?**

Markets cycle through structurally different states — calm uptrends, fragile rallies, quiet deterioration, and outright panic. Each state has a different risk/reward profile. Knowing which state you are in is the foundation for any sound portfolio decision.

The framework classifies every trading day into one of six regimes:

| Regime | Trend | Volatility | Interpretation |
|---|---|---|---|
| **RISK\_ON** | UP | LOW | Structurally rewarding environment; shallow drawdowns |
| **RISK\_ON\_FRAGILE** | UP | MEDIUM | Uptrend intact but stress is rising; caution warranted |
| **BULL\_EXPANSION** | UP | HIGH | Late-cycle momentum; high returns but elevated risk |
| **NEUTRAL** | NEUTRAL | ANY | No dominant trend; choppy, signal-poor environment |
| **RISK\_OFF\_TRANSITION** | DOWN | LOW/MED | Quiet de-risking; often underestimated by investors |
| **RISK\_OFF** | DOWN | HIGH | Forced selling, deleveraging, capital preservation |

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run with default SPY data
python run.py

# Run with a different ticker
python run.py QQQ
```

The script downloads data automatically, prints a live regime signal to the terminal, opens all visualisation windows, and exports two CSV files.

---

## How It Works

### 1. Features (`features.py`)

All inputs are derived from daily closing prices — no external data.

| Feature | Formula | Purpose |
|---|---|---|
| Log return | `r_t = log(P_t / P_{t-1})` | Risk measurement input |
| Realised vol (20d) | `σ = sqrt(252) × std(r_{t-19:t})` | Volatility state variable |
| 200-day MA | Simple moving average | Long-term trend proxy |
| Trend distance | `(P_t − MA_200) / MA_200` | Trend conviction measure |

### 2. State Variables (`method1.py`)

**Trend state** — derived from price position relative to MA\_200:
- `UP`: price above MA
- `DOWN`: price below MA
- `NEUTRAL`: price near MA

**Volatility state** — derived from quantile thresholds calibrated on 2000–2020 data only (no look-ahead):
- `LOW` / `MEDIUM` / `HIGH`
- Smoothed with a 5-day rolling majority vote to suppress noise-induced flickers

### 3. Persistence Filter

A new regime must hold for **3 consecutive days** before being accepted. Until then, the previous regime is carried forward. This eliminates spurious one-day transitions without any look-ahead.

### 4. Confidence Score

A composite `[0, 1]` signal measuring how clearly the market is expressing the detected regime:

```
Confidence = 0.4 × TrendScore + 0.3 × VolScore + 0.3 × DurationScore
```

All thresholds are calibration-period constants — no out-of-sample data re-enters the formula.

---

## Project Structure

```
├── data.py          # Downloads price data via yfinance
├── features.py      # Computes returns, volatility, MA, trend distance
├── method1.py       # Core regime detection engine
├── analytics.py     # Per-regime performance statistics
├── plotting.py      # All visualisations (6 chart types)
├── run.py           # End-to-end pipeline entry point
├── requirements.txt
└── README.md
```

---

## Outputs

Running `run.py` produces:

**Terminal output**
```
2025-02-25 | RISK_ON_FRAGILE      | Trend: UP     | Vol: MEDIUM | Conf: [████████████░░░░░░░░] 61.3%
```

**Visualisations**
- Main regime chart — price, 200-day MA, colour-coded regime backgrounds
- Regime timeline heatmap — duration and transitions at a glance
- Confidence overlay — price with regime confidence as secondary axis
- Performance dashboard — return, Sharpe, drawdown, time allocation (2×2 grid)
- Current regime card — snapshot of today's signal
- Transition matrix — empirical probability of moving from one regime to another

**CSV exports**
- `regime_history.csv` — day-by-day price, trend state, vol state, regime, confidence
- `regime_statistics.csv` — annualised return, volatility, Sharpe, max drawdown per regime

---

## Empirical Notes

Backtest results on SPY (2000–present) show that RISK\_ON often records lower raw annualised returns than RISK\_ON\_FRAGILE or BULL\_EXPANSION. This is by design, not a defect.

Low-volatility uptrends include mature bull market plateaus — extended periods where price grinds sideways. Raw returns average near zero during these phases even though the structural signal is correct. The more volatile bullish regimes involve active price discovery where both returns and risk are higher.

**The right metrics for RISK\_ON are Sharpe ratio and maximum drawdown, not raw return.**

---

## Limitations

- **Calibration window**: thresholds are fixed to 2000–2020 SPY data. Applying this to other assets or recalibrating for post-2020 data may change threshold values.
- **Lagging by construction**: the 200-day MA and 20-day vol window introduce inherent lag. Regime changes are confirmed, not predicted.
- **No risk-free rate**: Sharpe ratios are gross (no deduction). Adjust for your own cost of capital.
- **Single asset**: the framework was designed for a broad equity index. Individual stocks with different vol profiles may require recalibration.

---

## Design Principles

- **No look-ahead bias** — all thresholds are estimated on the calibration window and applied as constants to the full dataset
- **No machine learning** — fully deterministic and inspectable
- **No external data** — price series only
- **Extensible** — designed as a base layer; the regime signal is a clean input for overlay strategies or more complex models
